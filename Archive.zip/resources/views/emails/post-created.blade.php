A new post is created with Title: {{ $title }} 
and content including,
{{ $content }}