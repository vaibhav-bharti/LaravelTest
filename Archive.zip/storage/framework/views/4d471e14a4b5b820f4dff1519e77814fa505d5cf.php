A new post is created with Title: <?php echo e($title); ?> 
and content including,
<?php echo e($content); ?><?php /**PATH /Library/WebServer/Documents/test-project/resources/views/emails/post-created.blade.php ENDPATH**/ ?>